package westat;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;

public class Home {

	private JFrame frmInternetChallenge;
	private JTextField txttotalvalue;
	private JTextField txtAvgorder;
	private JTextField txtAddNewNickName;
	private JTextField textFieldNickName;
	private float total;
	private int selectedProducts;

	private String customer_id = null;
	private String customer_name = null;
	private String nickName = null;
	private String average = null;
	private String appendNickname = null;
	private String nick_name = null;
	//private String connectionURL = "jdbc:sqlite:" + this.getClass().getResource("/").getPath()+"Northwind.db";
	private String connectionURL = "jdbc:sqlite::resource:Northwind.db";
	
	@SuppressWarnings("rawtypes")
	List product_list = new ArrayList();

	public int getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(int selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	/**
	 * Launch the application.
	 */

	String home = System.getProperty("user.home");

	private Product[] productArray;

	public Product[] getProductArray() {
		return productArray;
	}

	public void setProductArray(Product[] productArray) {
		this.productArray = productArray;
	}

	private Customer[] customerArray;

	public Customer[] getCustomerArray() {
		return customerArray;
	}

	public void setCustomerArray(Customer[] customerArray) {
		this.customerArray = customerArray;
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Home window = new Home();
					window.frmInternetChallenge.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize() {

		connect();

		frmInternetChallenge = new JFrame();
		frmInternetChallenge.setTitle("Interview Challenge");
		frmInternetChallenge.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.setBounds(100, 100, 1653, 745);
		frmInternetChallenge.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		System.out.println(this.getCustomerArray().length);

		JButton btnAddNewNickname = new JButton("Add new Nickname");
		btnAddNewNickname.setBounds(401, 268, 378, 68);
		btnAddNewNickname.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnAddNewNickname.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				// Customer
				// custobj=(Customer)customer_comboBox.getSelectedItem();
				// System.out.println("customer_comboBox:"+custobj);

				String textFieldValue = txtAddNewNickName.getText();
				appendNickname = nickName + "," + textFieldValue;

				System.out.println("appendNickname:" + appendNickname);
				System.out.println("customer_id:" + customer_id);
				textFieldNickName.setText(appendNickname);
				nick_name = appendNickname;
				try {
					// String connectionURL =
					// "jdbc:sqlite:C:\\devops\\sqlite\\Northwind.db";
				//	String connectionURL = "jdbc:sqlite:C:\\devops\\sqlite\\Northwind.db";
					Connection connection;
					Class.forName("org.sqlite.JDBC");
					connection = DriverManager.getConnection(connectionURL, "root", "root");

					String updateNickName = "Update customers set nicknames='" + appendNickname + "' where customerid='"
							+ customer_id + "'";
					PreparedStatement ps = connection.prepareStatement(updateNickName);

					ps.executeUpdate();
					ps.close();

				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}
		});
		frmInternetChallenge.getContentPane().setLayout(null);

		JComboBox customer_comboBox = new JComboBox();
		customer_comboBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("I am watching !!!!!!!!!!!!" + customer_comboBox.getSelectedItem());
				Customer custobj = (Customer) customer_comboBox.getSelectedItem();
				customer_name = custobj.toString();
				customer_id = custobj.getCustomerID();
				System.out.println("Customer Name selected is ..." + customer_name);
				System.out.println("the NickName is !!!!!!!!!!!!" + custobj.getNickNames());
				textFieldNickName.setText(custobj.getNickNames());

				nickName = textFieldNickName.getText();
				System.out.println("nickName  selected is ..." + nickName);
				nick_name = nickName;

			}
		});
		customer_comboBox.setBounds(35, 63, 645, 40);
		customer_comboBox.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(customer_comboBox);
		DefaultComboBoxModel mod = new DefaultComboBoxModel(this.getCustomerArray());
		customer_comboBox.setModel(mod);

		JLabel lblCustomer = new JLabel("Customer");
		lblCustomer.setBounds(35, 0, 148, 77);
		lblCustomer.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblCustomer);

		JLabel lblProducts = new JLabel("Products");
		lblProducts.setBounds(819, 0, 134, 77);
		lblProducts.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblProducts);

		JList list = new JList();
		list.setBounds(0, 0, 0, 0);
		frmInternetChallenge.getContentPane().add(list);

		JLabel lblNicknames = new JLabel("Nick Names");
		lblNicknames.setBounds(35, 135, 361, 37);
		lblNicknames.setFont(new Font("Tahoma", Font.PLAIN, 35));
		frmInternetChallenge.getContentPane().add(lblNicknames);

		textFieldNickName = new JTextField();
		textFieldNickName.setBounds(35, 179, 744, 49);
		textFieldNickName.setEditable(false);
		textFieldNickName.setFont(new Font("Tahoma", Font.PLAIN, 30));
		textFieldNickName.setColumns(10);
		frmInternetChallenge.getContentPane().add(textFieldNickName);

		txtAddNewNickName = new JTextField();
		txtAddNewNickName.setFont(new Font("Tahoma", Font.PLAIN, 30));
		txtAddNewNickName.setBounds(35, 268, 361, 68);
		txtAddNewNickName.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAddNewNickName);
		frmInternetChallenge.getContentPane().add(btnAddNewNickname);

		JLabel lblTotalValue = new JLabel("Total Value ($)");
		lblTotalValue.setBounds(35, 467, 229, 43);
		lblTotalValue.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblTotalValue);

		JLabel lblAveragePer = new JLabel("Average $ Per Order");
		lblAveragePer.setBounds(784, 467, 314, 43);
		lblAveragePer.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(lblAveragePer);

		JButton btnExportToHtml = new JButton("Export to HTML");
		btnExportToHtml.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					exportToHTML();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// JOptionPane.showMessageDialog(btnExportToHtml, "Please find
				// the file here
				// \"D:"+"\\"+"workspace"+"\\"+"TestingAWT"+"\\"+"classes"+"\\"+"Export.html");

				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18)));
				JOptionPane.showMessageDialog(btnExportToHtml,
						"Please find the file here:" + home + "\\" + "Downloads" + "\\" + "Export.html", "Downloaded",
						1);

			}

		});
		btnExportToHtml.setBounds(1184, 521, 283, 63);
		btnExportToHtml.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(btnExportToHtml);

		txttotalvalue = new JTextField();
		txttotalvalue.setBounds(35, 535, 361, 49);
		txttotalvalue.setEditable(false);
		txttotalvalue.setFont(new Font("Tahoma", Font.PLAIN, 35));
		txttotalvalue.setColumns(10);
		frmInternetChallenge.getContentPane().add(txttotalvalue);

		txtAvgorder = new JTextField();
		txtAvgorder.setBounds(784, 535, 366, 49);
		txtAvgorder.setFont(new Font("Tahoma", Font.PLAIN, 35));
		txtAvgorder.setEditable(false);
		txtAvgorder.setColumns(10);
		frmInternetChallenge.getContentPane().add(txtAvgorder);

		JButton btnExportToCSV = new JButton("Export to CSV");
		btnExportToCSV.setBounds(1184, 592, 283, 69);
		btnExportToCSV.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				exportToCSV();
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Arial", Font.BOLD, 18)));

				JOptionPane.showMessageDialog(btnExportToCSV,
						"Please find the file here:" + home + "\\" + "Downloads" + "\\" + "Export.csv", "Downloaded",
						1);

			}

		});
		btnExportToCSV.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmInternetChallenge.getContentPane().add(btnExportToCSV);

		CheckboxGroup cbg = new CheckboxGroup();
		frmInternetChallenge.getContentPane().add(new Checkbox("one", cbg, true));
		frmInternetChallenge.getContentPane().add(new Checkbox("two", cbg, false));
		frmInternetChallenge.getContentPane().add(new Checkbox("three", cbg, false));
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(819, 63, 717, 387);
		frmInternetChallenge.getContentPane().add(scrollPane);

		Box verticalBoxProductList = Box.createVerticalBox();
		scrollPane.setViewportView(verticalBoxProductList);
		verticalBoxProductList.setFont(new Font("Tahoma", Font.PLAIN, 30));
		verticalBoxProductList.setBorder(new LineBorder(new Color(0, 0, 0)));
		// int j=0;
		System.out.println("The Size of ProductArray is " + this.getProductArray().length);

		for (int i = 0; i < this.getProductArray().length; i++) {
			// System.out.println("The ProductID is *********
			// "+this.getProductArray()[i].getProduc());
			JCheckBox chckbxProduct = new JCheckBox();
			chckbxProduct.setFont(new Font("Tahoma", Font.PLAIN, 30));
			chckbxProduct.setText(this.getProductArray()[i].getProductName());
			chckbxProduct.setName(this.getProductArray()[i].getUnitPrice());
			// chckbxProduct.setBounds(887, 100+j, 143, 29);
			// chckbxProduct.add
			// frame.getContentPane().add(chckbxProduct);
			// cbg.add(chckbxProduct);

			chckbxProduct.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					if (chckbxProduct.isSelected()) {
						total = total + Float.valueOf(chckbxProduct.getName());
						selectedProducts = selectedProducts + 1;
						product_list.add(chckbxProduct.getText());
						System.out.println("product_list" + product_list);
					}
					if (!chckbxProduct.isSelected()) {
						total = total - Float.valueOf(chckbxProduct.getName());
						selectedProducts = selectedProducts - 1;
					}
					txttotalvalue.setText(String.valueOf(total));
					txtAvgorder.setText(String.valueOf(total / selectedProducts));

					System.out.println("Average:" + txtAvgorder.getText());
					average = txtAvgorder.getText();
					System.out.println("the total is " + total);
				}
			});
			verticalBoxProductList.add(chckbxProduct);
			// verticalBoxProductList.add(new
			// Checkbox(this.getProductList().get(i).toString(), cbg, true));
			// frmInternetChallenge.getContentPane().add(new
			// Checkbox(this.getProductList().get(i).toString(), cbg, true));
			// j=j+25;
		}

	}

	@SuppressWarnings("rawtypes")
	public void connect()

	{

		// String connectionURL =
		// "jdbc:sqlite:C:\\devops\\sqlite\\Northwind.db";
		
		System.out.println("connectionURL......" + connectionURL);
		Connection connection;
		ResultSet rs;

		List custlist = new ArrayList();
		List prodlist = new ArrayList();

		Customer[] custArray = new Customer[93];
		Product[] productArray = new Product[77];

		try {

			// Load the database driver
			Class.forName("org.sqlite.JDBC");
			// Get a Connection to the database

			connection = DriverManager.getConnection(connectionURL, "root", "root");
			// Select the data from the database
			// s.executeQuery (sql);
			java.sql.Statement stmt = connection.createStatement();
			String selectquery = "select * from products";

			rs = stmt.executeQuery(selectquery);
			int i = 0;
			while (rs.next()) {

				// Add records into data list
				// dataList.add(rs.getString("ProductId"));
				Product productobj = new Product();
				productobj.setProductID(rs.getString("ProductId"));
				productobj.setProductName(rs.getString("ProductName"));
				productobj.setQuantityPerUnit(rs.getString("QuantityPerUnit"));
				productobj.setUnitPrice(rs.getString("UnitPrice"));
				productArray[i++] = productobj;

			}
			System.out.println("Produclist:" + prodlist);

			String sqlCustomer = "select * from customers";

			rs = stmt.executeQuery(sqlCustomer);
			// Customer[] custArray=new Customer[rs];
			i = 0;
			while (rs.next()) {

				// Add records into data list
				// custlist.add(rs.getString("CompanyName"));
				Customer custobject = new Customer();
				custobject.setCustomerID(rs.getString("CustomerID"));
				custobject.setContactName(rs.getString("CompanyName"));
				custobject.setNickNames(rs.getString("NickNames"));

				custArray[i++] = custobject;
			}

			System.out.println("custlist:" + custlist);
			// this.setCustomerList(custlist);
			this.setCustomerArray(custArray);
			this.setProductArray(productArray);
			// System.out.println(" Customer and Product
			// added"+this.getCustomerList().size()+this.getProductList().size());

			rs.close();
		} catch (Exception e) {

			System.out.println("Exception is ;" + e);

		}
	}

	public void exportToCSV() {

		PrintWriter writer = null;

		try {
			writer = new PrintWriter(home + "/Downloads/" + "Export.csv", "UTF-8");

			writer.println("Customer,NickName,Products,Total,Avg");
			writer.print(customer_name + "," + nick_name + "," + product_list + "," + total + "," + average);

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			writer.close();
		}
	}

	public void exportToHTML() throws SQLException, ClassNotFoundException {

		PrintWriter writer = null;

		//String connectionURL = "jdbc:sqlite:C:\\devops\\sqlite\\Northwind.db";
		Connection connection;
		ResultSet rs;
		// List orderReport= new ArrayList<>();

		try {

			Class.forName("org.sqlite.JDBC");

			connection = DriverManager.getConnection(connectionURL, "root", "root");

			System.out.println("customer_id:" + customer_id);
			// String ordersql ="select * from orders where CustomerID=?";
			// PreparedStatement pstmt = connection.prepareStatement(ordersql);

			String ordersql = "select * from orders ord,Employees Emp where customerid=" + "'" + customer_id + "'";
			System.out.println("ordersql:" + ordersql);
			java.sql.Statement stmt = connection.createStatement();
			// rs.setString(1,customer_id);
			rs = stmt.executeQuery(ordersql);
			// pstmt.setString(1,customer_id);

			// rs = pstmt.executeQuery(ordersql);

			writer = new PrintWriter(home + "/Downloads/" + "Export.html", "UTF-8");
			writer.println("<!DOCTYPE html>");
			writer.println("<html>");
			writer.println("<head>");
			writer.println("</head>");
			writer.println("<body>");
			writer.println("<table>");
			writer.println("<tr>");
			writer.println("<th align=\"left\">Customer Name</th>");
			writer.println("<th align=\"left\">Nick Names</th>");
			writer.println("<th align=\"left\">Products</th>");
			writer.println("<th align=\"left\">Total($)</th>");
			writer.println("<th align=\"left\">Average($)</th>");
			writer.println("</tr>");
			while (rs.next()) {

				writer.println("<tr>");
				writer.println("<td>" + rs.getString("OrderID") + "</td>");
				writer.println("<td>" + rs.getString("CustomerID") + "</td>");
				writer.println("<td>" + rs.getString("EmployeeID") + "</td>");

				writer.println("</tr>");
			}

			writer.println("</body>");
			writer.println("</body>");
			writer.println("</html>");

		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			writer.close();
		}
	}
}
